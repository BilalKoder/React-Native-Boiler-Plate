export type SignUpFormType = {
    Email: string;
    Password: string;
    ConfirmPassword: string
} 