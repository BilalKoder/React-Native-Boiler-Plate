export interface EmailConfirmationType {
    Email: string;
}