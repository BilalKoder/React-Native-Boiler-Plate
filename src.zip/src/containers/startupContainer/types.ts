export type getUserType = {
    version: string;
}