export type ResetFormType = {
    NewPassword: string;
    ConfirmNewPassword: string
} 