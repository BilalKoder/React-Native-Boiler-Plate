import * as Colors from "./Colors";
import Fonts from "./Fonts";
import * as AppStyles from "./AppStyles";

export { Colors, Fonts, AppStyles };
