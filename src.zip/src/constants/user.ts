export enum user_login_type {
    EMAIL = 1,
    PHONE = 2,
}