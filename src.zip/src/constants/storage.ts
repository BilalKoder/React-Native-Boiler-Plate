const STORAGE_CONST = {
    TOKEN: "TOKEN",
    GET_USER: "GET_USER",
}

export default STORAGE_CONST;