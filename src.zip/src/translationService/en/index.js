import common from "./common";
import errors from "./errors";
import pageTitles from "./pageTitles";

export default {
    common,
    errors,
    pageTitles
}