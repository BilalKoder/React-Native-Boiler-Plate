export default {
    SPLASH: "Splash Screen",
    HOME: "My home",
    LOGIN: "Login",
    SIGNUP: "SignUp",
    EMAIL_CONFIRMATION: "Email Confirmation",
    ENTER_OTP: "Enter OTP",
    RESET_PASSWORD: "Reset Password",
    CHAT: "AP-Physics",
  
}