export default {
    email: "Email",
    signIn: "Sign In",
    submit: "Submit",
    updatePassword: "Update Password",
    signUp: "Sign Up",
    password: "Password",
    confirmPassword: "Confirm Password",
    languageSelector: 'Select Your Language'
};
