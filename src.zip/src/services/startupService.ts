import STORAGE_CONST from "../constants/storage";
import { queryClient } from "../APIServices/Client";

export function Init() {
    console.log({ hello: "hello" });
}